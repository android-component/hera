define("pages/2048/grid.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

function Board(size) {
  this.size = size;
  this.grid = this.init();
}
Board.prototype = {
  init: function init() {
    // 形成一个空矩阵
    var grid = [];
    for (var i = 0; i < this.size; i++) {
      grid[i] = [];
      for (var j = 0; j < this.size; j++) {
        grid[i].push("");
      }
    }
    return grid;
  },
  usefulCell: function usefulCell() {
    // 记录为空的格子
    var cells = [];
    for (var i = 0; i < this.size; i++) {
      for (var j = 0; j < this.size; j++) {
        if (this.grid[i][j] == "") {
          // 若可用则记录坐标
          cells.push({
            x: i,
            y: j
          });
        }
      }
    }return cells;
  },
  selectCell: function selectCell() {
    // 从可填充格子中随机选一个
    var cells = this.usefulCell();
    if (cells.length) {
      return cells[Math.floor(Math.random() * cells.length)];
    }
  },
  cellEmpty: function cellEmpty() {
    // 可用格子是否为空，为空返回true
    return !this.usefulCell().length;
  }
};

module.exports = Board;
});
define("pages/2048/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var Board = require("./grid.js");

function Main(size) {
  this.size = size;
  this.startData = 2; // 初始填充2个数据
  this.init();
}

Main.prototype = {
  init: function init() {
    // 填充数据
    this.board = new Board(this.size);
    this.bproto = this.board.__proto__;
    this.setDataRandom(); // 随机填充 
    this.startData = 1;
  },
  setDataRandom: function setDataRandom() {
    // 随机填充
    for (var i = 0; i < this.startData; i++) {
      this.addRandomData();
    }
  },
  addRandomData: function addRandomData() {
    //填充数据
    if (!this.board.cellEmpty()) {
      var value = Math.random() < 0.9 ? 2 : 4;
      var cell = this.board.selectCell();
      cell.val = value;
      this.update(cell);
    }
  },
  update: function update(cell) {
    // 更新数据
    this.board.grid[cell.x][cell.y] = cell.val;
  },
  move: function move(dir) {
    // 0:上, 1:右, 2:下, 3:左
    var curList = this.formList(dir);

    var list = this.combine(curList);
    var result = [[], [], [], []];

    for (var i = 0; i < this.size; i++) {
      for (var j = 0; j < this.size; j++) {
        switch (dir) {
          case 0:
            result[i][j] = list[j][i];
            break;
          case 1:
            result[i][j] = list[i][this.size - 1 - j];
            break;
          case 2:
            result[i][j] = list[j][this.size - 1 - i];
            break;
          case 3:
            result[i][j] = list[i][j];
            break;
        }
      }
    }this.board.grid = result;
    this.setDataRandom();

    return result;
  },
  formList: function formList(dir) {
    // 根据滑动方向生成list的四个数组
    var list = [[], [], [], []];
    for (var i = 0; i < this.size; i++) {
      for (var j = 0; j < this.size; j++) {
        switch (dir) {
          case 0:
            list[i].push(this.board.grid[j][i]);
            break;
          case 1:
            list[i].push(this.board.grid[i][this.size - 1 - j]);
            break;
          case 2:
            list[i].push(this.board.grid[this.size - 1 - j][i]);
            break;
          case 3:
            list[i].push(this.board.grid[i][j]);
            break;
        }
      }
    }return list;
  },
  combine: function combine(list) {
    // 滑动时相同的合并
    for (var i = 0; i < list.length; i++) {
      // 数字靠边
      list[i] = this.changeItem(list[i]);
    }for (var i = 0; i < this.size; i++) {
      for (var j = 1; j < this.size; j++) {
        if (list[i][j - 1] == list[i][j] && list[i][j] != "") {
          list[i][j - 1] += list[i][j];
          list[i][j] = "";
        }
      }
    }
    for (var i = 0; i < list.length; i++) {
      // 再次数字靠边
      list[i] = this.changeItem(list[i]);
    }return list;
  },
  changeItem: function changeItem(item) {
    // 将 ['', 2, '', 2] 改为 [2, 2, '', '']
    var cnt = 0;
    for (var i = 0; i < item.length; i++) {
      if (item[i] != '') item[cnt++] = item[i];
    }for (var j = cnt; j < item.length; j++) {
      item[j] = "";
    }return item;
  },
  isOver: function isOver() {
    // 游戏是否结束，结束条件：可用格子为空且所有格子上下左右值不等
    this.board.__proto__ = this.bproto;
    if (!this.board.cellEmpty()) {
      return false;
    } else {
      for (var i = 0; i < this.size; i++) {
        // 左右不等
        for (var j = 1; j < this.size; j++) {
          if (this.board.grid[i][j] == this.board.grid[i][j - 1]) return false;
        }
      }for (var j = 0; j < this.size; j++) {
        // 上下不等
        for (var i = 1; i < this.size; i++) {
          if (this.board.grid[i][j] == this.board.grid[i - 1][j]) return false;
        }
      }
    }
    return true;
  }
};

module.exports = Main;
});
define("utils/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var formatTime = function formatTime(date) {
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':');
};

var formatNumber = function formatNumber(n) {
  n = n.toString();
  return n[1] ? n : '0' + n;
};

module.exports = {
  formatTime: formatTime
};
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

//app.js
App({
  onLaunch: function onLaunch() {
    var _this = this;

    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || [];
    logs.unshift(Date.now());
    wx.setStorageSync('logs', logs);

    // 登录
    wx.login({
      success: function success(res) {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    });
    // 获取用户信息
    wx.getSetting({
      success: function success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: function success(res) {
              // 可以将 res 发送给后台解码出 unionId
              _this.globalData.userInfo = res.userInfo;

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (_this.userInfoReadyCallback) {
                _this.userInfoReadyCallback(res);
              }
            }
          });
        }
      }
    });
  },
  globalData: {
    userInfo: null
  }
});
});require("app.js")
var __wxRoute = "pages/index/index", __wxRouteBegin = true;
define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

//index.js
//获取应用实例
var app = getApp();

Page({
  data: {
    current: 0
  },
  onReady: function onReady() {
    this.load();
  },
  load: function load() {
    var _this = this;

    var n = 1;
    var timer = setInterval(function () {
      if (n == 6) {
        clearInterval(timer);
        wx.redirectTo({
          url: '../2048/2048'
        });
      }
      _this.setData({
        current: _this.data.current + 1
      });
      if (_this.data.current > 3) _this.setData({
        current: 0
      });
      n++;
    }, 400);
  }
});
});require("pages/index/index.js")
var __wxRoute = "pages/2048/2048", __wxRouteBegin = true;
define("pages/2048/2048.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var Board = require("./grid.js");
var Main = require("./main.js");

Page({
  data: {
    hidden: false,
    start: "开始游戏",
    num: [],
    score: 0,
    bestScore: 0, // 最高分
    endMsg: '',
    over: false // 游戏是否结束 
  },
  // 页面渲染完成
  onReady: function onReady() {
    if (!wx.getStorageSync("highScore")) wx.setStorageSync('highScore', 0);
    this.gameStart();
  },
  gameStart: function gameStart() {
    // 游戏开始
    var main = new Main(4);
    this.setData({
      main: main,
      bestScore: wx.getStorageSync('highScore')
    });
    this.data.main.__proto__ = main.__proto__;

    this.setData({
      hidden: true,
      over: false,
      score: 0,
      num: this.data.main.board.grid
    });
  },
  gameOver: function gameOver() {
    // 游戏结束
    this.setData({
      over: true
    });

    if (this.data.score >= 2048) {
      this.setData({
        endMsg: '恭喜达到2048！'
      });
      wx.setStorageSync('highScore', this.data.score);
    } else if (this.data.score > this.data.bestScore) {
      this.setData({
        endMsg: '创造新纪录！'
      });
      wx.setStorageSync('highScore', this.data.score);
    } else {
      this.setData({
        endMsg: '游戏结束！'
      });
    }
  },
  // 触摸
  touchStartX: 0,
  touchStartY: 0,
  touchEndX: 0,
  touchEndY: 0,
  touchStart: function touchStart(ev) {
    // 触摸开始坐标
    var touch = ev.touches[0];
    this.touchStartX = touch.clientX;
    this.touchStartY = touch.clientY;
  },
  touchMove: function touchMove(ev) {
    // 触摸最后移动时的坐标
    var touch = ev.touches[0];
    this.touchEndX = touch.clientX;
    this.touchEndY = touch.clientY;
  },
  touchEnd: function touchEnd() {
    var disX = this.touchStartX - this.touchEndX;
    var absdisX = Math.abs(disX);
    var disY = this.touchStartY - this.touchEndY;
    var absdisY = Math.abs(disY);

    if (this.data.main.isOver()) {
      // 游戏是否结束
      this.gameOver();
    } else {
      if (Math.max(absdisX, absdisY) > 10) {
        // 确定是否在滑动
        this.setData({
          start: "重新开始"
        });
        var direction = absdisX > absdisY ? disX < 0 ? 1 : 3 : disY < 0 ? 2 : 0; // 确定移动方向
        var data = this.data.main.move(direction);
        this.updateView(data);
      }
    }
  },
  updateView: function updateView(data) {
    var max = 0;
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < 4; j++) {
        if (data[i][j] != "" && data[i][j] > max) max = data[i][j];
      }
    }this.setData({
      num: data,
      score: max
    });
  },

  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '2048小游戏',
      desc: '来试试你能达到多少分',
      path: '/page/user?id=123'
    };
  }
});
});require("pages/2048/2048.js")
var __wxRoute = "pages/logs/logs", __wxRouteBegin = true;
define("pages/logs/logs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

//logs.js
var util = require('../../utils/util.js');

Page({
  data: {
    logs: []
  },
  onLoad: function onLoad() {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(function (log) {
        return util.formatTime(new Date(log));
      })
    });
  }
});
});require("pages/logs/logs.js")