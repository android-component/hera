define("utils/baidu.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var URI = 'https://api.map.baidu.com';
var fetch = require('./fetch');

function fetchApi(type, params) {
  return fetch(URI, type, params);
}

/**
 * 根据经纬度获取城市
 * @param  {Number} latitude   经度
 * @param  {Number} longitude  纬度
 * @return {Promise}       包含抓取任务的Promise
 */
function getCityName() {
  var latitude = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 39.90403;
  var longitude = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 116.407526;

  var params = { location: latitude + ',' + longitude, output: 'json', ak: 'B61195334f65b9e4d02ae75d24fa2c53' };
  return fetchApi('geocoder/v2/', params).then(function (res) {
    return res.data.result.addressComponent.city;
  });
}

module.exports = { getCityName: getCityName };
});
define("utils/douban.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var URI = 'https://douban-api.uieee.com/v2/movie';
var fetch = require('./fetch');

/**
 * 抓取豆瓣电影特定类型的API
 * https://developers.douban.com/wiki/?title=movie_v2
 * @param  {String} type   类型，例如：'coming_soon'
 * @param  {Objece} params 参数
 * @return {Promise}       包含抓取任务的Promise
 */
function fetchApi(type, params) {
  return fetch(URI, type, params);
}

/**
 * 获取列表类型的数据
 * @param  {String} type   类型，例如：'coming_soon'
 * @param  {Number} page   页码
 * @param  {Number} count  页条数
 * @param  {String} search 搜索关键词
 * @return {Promise}       包含抓取任务的Promise
 */
function find(type) {
  var page = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
  var count = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 20;
  var search = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';

  var params = { start: (page - 1) * count, count: count, city: getApp().data.currentCity };
  return fetchApi(type, search ? Object.assign(params, { q: search }) : params).then(function (res) {
    return res.data;
  });
}

/**
 * 获取单条类型的数据
 * @param  {Number} id     电影ID
 * @return {Promise}       包含抓取任务的Promise
 */
function findOne(id) {
  return fetchApi('subject/' + id).then(function (res) {
    return res.data;
  });
}

module.exports = { find: find, findOne: findOne };
});
define("utils/fetch.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * 抓取远端API的结构
 * https://developers.douban.com/wiki/?title=movie_v2
 * @param  {String} api    api 根地址
 * @param  {String} path   请求路径
 * @param  {Objece} params 参数
 * @return {Promise}       包含抓取任务的Promise
 */
module.exports = function (api, path, params) {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: api + '/' + path,
      data: Object.assign({}, params),
      header: { 'Content-Type': 'json' },
      success: resolve,
      fail: reject
    });
  });
};
});
define("utils/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * 格式化时间
 * @param  {Datetime} source 时间对象
 * @param  {String} format 格式
 * @return {String}        格式化过后的时间
 */
function formatDate(source, format) {
  var o = {
    'M+': source.getMonth() + 1, // 月份
    'd+': source.getDate(), // 日
    'H+': source.getHours(), // 小时
    'm+': source.getMinutes(), // 分
    's+': source.getSeconds(), // 秒
    'q+': Math.floor((source.getMonth() + 3) / 3), // 季度
    'f+': source.getMilliseconds() // 毫秒
  };
  if (/(y+)/.test(format)) {
    format = format.replace(RegExp.$1, (source.getFullYear() + '').substr(4 - RegExp.$1.length));
  }
  for (var k in o) {
    if (new RegExp('(' + k + ')').test(format)) {
      format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }
  return format;
}

module.exports = { formatDate: formatDate };
});
define("utils/wechat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

function login() {
  return new Promise(function (resolve, reject) {
    wx.login({ success: resolve, fail: reject });
  });
}

function getUserInfo() {
  return new Promise(function (resolve, reject) {
    wx.getUserInfo({ success: resolve, fail: reject });
  });
}

function setStorage(key, value) {
  return new Promise(function (resolve, reject) {
    wx.setStorage({ key: key, data: value, success: resolve, fail: reject });
  });
}

function getStorage(key) {
  return new Promise(function (resolve, reject) {
    wx.getStorage({ key: key, success: resolve, fail: reject });
  });
}

function getLocation(type) {
  return new Promise(function (resolve, reject) {
    wx.getLocation({ type: type, success: resolve, fail: reject });
  });
}

module.exports = {
  login: login,
  getUserInfo: getUserInfo,
  setStorage: setStorage,
  getStorage: getStorage,
  getLocation: getLocation,
  original: wx
};
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * WeChat API 模块
 * @type {Object}
 * 用于将微信官方`API`封装为`Promise`方式
 * > 小程序支持以`CommonJS`规范组织代码结构
 */
var wechat = require('./utils/wechat.js');

/**
 * Douban API 模块
 * @type {Object}
 */
var douban = require('./utils/douban.js');

/**
 * Baidu API 模块
 * @type {Object}
 */
var baidu = require('./utils/baidu.js');

App({
  /**
   * Global shared
   * 可以定义任何成员，用于在整个应用中共享
   */
  data: {
    name: 'Douban Movie',
    version: '0.1.0',
    currentCity: '北京'
  },

  /**
   * WeChat API
   */
  wechat: wechat,

  /**
   * Douban API
   */
  douban: douban,

  /**
   * Baidu API
   */
  baidu: baidu,

  /**
   * 生命周期函数--监听小程序初始化
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
   */
  onLaunch: function onLaunch() {
    var _this = this;

    wechat.getLocation().then(function (res) {
      var latitude = res.latitude,
          longitude = res.longitude;

      return baidu.getCityName(latitude, longitude);
    }).then(function (name) {
      _this.data.currentCity = name.replace('市', '');
      console.log('currentCity : ' + _this.data.currentCity);
    }).catch(function (err) {
      _this.data.currentCity = '北京';
      console.error(err);
    });
  }
});
});require("app.js")
var __wxRoute = "pages/splash/splash", __wxRouteBegin = true;
define("pages/splash/splash.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    movies: [],
    loading: true
  },

  getCache: function getCache() {
    return new Promise(function (resolve) {
      app.wechat.getStorage('last_splash_data').then(function (res) {
        var _res$data = res.data,
            movies = _res$data.movies,
            expires = _res$data.expires;
        // 有缓存，判断是否过期

        if (movies && expires > Date.now()) {
          return resolve(res.data);
        }
        // 已经过期
        console.log('uncached');
        return resolve(null);
      }).catch(function (e) {
        return resolve(null);
      });
    });
  },
  handleStart: function handleStart() {
    // TODO: 访问历史的问题
    wx.switchTab({
      url: '../board/board'
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad() {
    var _this = this;

    this.getCache().then(function (cache) {
      if (cache) {
        return _this.setData({ movies: cache.movies, loading: false });
      }

      app.douban.find('coming_soon', 1, 1).then(function (d) {
        _this.setData({ movies: d.subjects, loading: false });
        return app.wechat.setStorage('last_splash_data', {
          movies: d.subjects,
          expires: Date.now() + 1 * 24 * 60 * 60 * 1000
        });
      }).then(function () {
        return console.log('storage last splash data');
      });
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    // TODO: onReady
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    // TODO: onShow
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {
    // TODO: onHide
  },


  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {
    // TODO: onUnload
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {
    // TODO: onPullDownRefresh
  }
});
});require("pages/splash/splash.js")
var __wxRoute = "pages/board/board", __wxRouteBegin = true;
define("pages/board/board.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    boards: [{ key: 'in_theaters' }, { key: 'coming_soon' }, { key: 'new_movies' }, { key: 'top250' }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad() {
    var _this = this;

    wx.showLoading({ title: '拼命加载中...' });

    var tasks = this.data.boards.map(function (board) {
      return app.douban.find(board.key, 1, 8).then(function (d) {
        board.title = d.title;
        board.movies = d.subjects;
        return board;
      });
    });

    Promise.all(tasks).then(function (boards) {
      _this.setData({ boards: boards, loading: false });
      wx.hideLoading();
    });
  }
});
});require("pages/board/board.js")
var __wxRoute = "pages/list/list", __wxRouteBegin = true;
define("pages/list/list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    title: '',
    subtitle: '加载中...',
    type: 'in_theaters',
    hasMore: true,
    page: 1,
    size: 20,
    movies: []
  },

  loadMore: function loadMore() {
    var _this = this;

    if (!this.data.hasMore) return;

    wx.showLoading({ title: '拼命加载中...' });
    this.setData({ subtitle: '加载中...' });

    return app.douban.find(this.data.type, this.data.page++, this.data.size).then(function (d) {
      if (d.subjects.length) {
        _this.setData({ subtitle: d.title, movies: _this.data.movies.concat(d.subjects) });
      } else {
        _this.setData({ subtitle: d.title, hasMore: false });
      }
      wx.hideLoading();
    }).catch(function (e) {
      _this.setData({ subtitle: '获取数据异常' });
      console.error(e);
      wx.hideLoading();
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(params) {
    this.data.title = params.title || this.data.title;

    // 类型： in_theaters  coming_soon  us_box
    this.data.type = params.type || this.data.type;

    this.loadMore();
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    wx.setNavigationBarTitle({ title: this.data.title + ' « 电影 « 豆瓣' });
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {
    this.setData({ movies: [], page: 1, hasMore: true });
    this.loadMore().then(function () {
      return wx.stopPullDownRefresh();
    });
  },
  onReachBottom: function onReachBottom() {
    this.loadMore();
  }
});
});require("pages/list/list.js")
var __wxRoute = "pages/item/item", __wxRouteBegin = true;
define("pages/item/item.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    title: '',
    movie: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(params) {
    var _this = this;

    wx.showLoading({ title: '拼命加载中...' });

    app.douban.findOne(params.id).then(function (d) {
      _this.setData({ title: d.title, movie: d });
      wx.setNavigationBarTitle({ title: d.title + ' « 电影 « 豆瓣' });
      wx.hideLoading();
    }).catch(function (e) {
      _this.setData({ title: '获取数据异常', movie: {} });
      console.error(e);
      wx.hideLoading();
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    wx.setNavigationBarTitle({ title: this.data.title + ' « 电影 « 豆瓣' });
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: this.data.title,
      desc: this.data.title,
      path: '/pages/item?id=' + this.data.id
    };
  }
});
});require("pages/item/item.js")
var __wxRoute = "pages/search/search", __wxRouteBegin = true;
define("pages/search/search.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    size: 20,
    // subtitle: '请在此输入搜索内容',
    subtitle: '搜索接口暂时无法使用',
    movies: [],
    search: '',
    loading: false,
    hasMore: false
  },

  loadMore: function loadMore() {
    var _this = this;

    if (!this.data.hasMore) return;

    this.setData({ subtitle: '加载中...', loading: true });

    return app.douban.find('search', this.data.page++, this.data.size, this.data.search).then(function (d) {
      if (d.subjects.length) {
        _this.setData({ subtitle: d.title, movies: _this.data.movies.concat(d.subjects), loading: false });
      } else {
        _this.setData({ hasMore: false, loading: false });
      }
    }).catch(function (e) {
      _this.setData({ subtitle: '获取数据异常', loading: false });
      console.error(e);
    });
  },
  handleSearch: function handleSearch(e) {
    if (!e.detail.value) return;
    this.setData({ movies: [], page: 1 });
    this.setData({ subtitle: '加载中...', hasMore: true, loading: true, search: e.detail.value });

    this.loadMore();
  },
  onReachBottom: function onReachBottom() {
    this.loadMore();
  }
});
});require("pages/search/search.js")
var __wxRoute = "pages/profile/profile", __wxRouteBegin = true;
define("pages/profile/profile.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面的初始数据
   */
  data: {
    title: 'About',
    userInfo: {
      wechat: 'WEDN-NET',
      nickName: 'https://github.com/zce/weapp-douban',
      avatarUrl: 'https://img.zce.me/qrcode/wechat.jpg'
    }
  },

  getUserInfo: function getUserInfo() {
    var _this = this;

    app.wechat.getUserInfo().then(function (res) {
      return _this.setData({ userInfo: res.userInfo });
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad() {
    app.wechat.login().then(function (res) {
      if (res.code) {
        console.log('登录成功！' + res.code);
      } else {
        console.error('获取用户登录态失败！' + res.errMsg);
      }
    });
  }
});
});require("pages/profile/profile.js")