/*
* @Author: mark
* @Date:   2016-10-10 15:29:40
* @Last Modified by:   mark
* @Last Modified time: 2016-10-10 17:15:55
*/

Page({

    data:{
        name: '的视频暂时没有'
    },

    onLoad: function(params){

        let name = params.name || this.data.name;

        this.setData({
            name: name
        })

      wx.setNavigationBarColor({//设置导航栏颜色
        frontColor: '#000000',//注意frontColor的值只能为000000或者111111
        backgroundColor: '#FFFFFF'
      });

    },

    onReady: function(){

        wx.setNavigationBarTitle({
            title:this.data.name
        })

    },

    videoErrorCallback: function(e){
        console.log(e);
    }
})